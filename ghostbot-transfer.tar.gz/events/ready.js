// Ready event - Fired when bot successfully connects to Discord
const logger = require("../utils/logger");
const config = require("../config");
const { storage } = require("../server/storage");

module.exports = {
    name: "ready",
    once: true,
    async execute(client) {
        logger.info(`Bot is ready! Logged in as ${client.user.tag}`);
        logger.info(
            `Serving ${client.guilds.cache.size} guild(s) with ${client.users.cache.size} users`,
        );

        // Initialize guilds in database
        for (const [guildId, guild] of client.guilds.cache) {
            try {
                const existingGuild = await storage.getGuild(guildId);
                if (!existingGuild) {
                    await storage.createGuild({
                        guildId: guildId,
                        name: guild.name,
                        icon: guild.icon,
                        ownerId: guild.ownerId,
                        memberCount: guild.memberCount,
                    });
                    logger.info(
                        `Added new guild to database: ${guild.name} (${guildId})`,
                    );
                } else {
                    // Update guild info
                    await storage.updateGuild(guildId, {
                        name: guild.name,
                        icon: guild.icon,
                        memberCount: guild.memberCount,
                    });
                }
            } catch (error) {
                logger.error(
                    `Failed to initialize guild ${guild.name}:`,
                    error,
                );
            }
        }

        // Set bot activity/status
        const activities = [
            {
                name: `${config.prefix}help | ${client.guilds.cache.size} servers`,
                type: 0,
            }, // Playing
            { name: "your confessions and rants", type: 2 }, // Listening
            { name: `${client.users.cache.size} users`, type: 3 }, // Watching
        ];

        let currentActivity = 0;

        // Set initial activity and status
        client.user.setPresence({
            activities: [
                {
                    name: activities[currentActivity].name,
                    type: activities[currentActivity].type,
                },
            ],
            status: "dnd", // online, idle, dnd, invisible
        });

        // Rotate activities every 30 seconds
        setInterval(() => {
            currentActivity = (currentActivity + 1) % activities.length;
            const activity = activities[currentActivity];

            // Update guild and user counts
            if (activity.name.includes("servers")) {
                activity.name = `${config.prefix}help | ${client.guilds.cache.size} servers`;
            } else if (activity.name.includes("users")) {
                activity.name = `${client.users.cache.size} users`;
            }

            client.user.setPresence({
                activities: [{ name: activity.name, type: activity.type }],
                status: "online", // online, idle, dnd, invisible
            });
        }, 30000);

        // Log memory usage
        const memUsage = process.memoryUsage();
        logger.info(
            `Memory usage: ${Math.round(memUsage.heapUsed / 1024 / 1024)}MB`,
        );

        // Set up periodic stats logging
        setInterval(() => {
            const memUsage = process.memoryUsage();
            logger.info(
                `Stats: ${client.guilds.cache.size} guilds, ${client.users.cache.size} users, ${Math.round(memUsage.heapUsed / 1024 / 1024)}MB memory`,
            );
        }, 300000); // Every 5 minutes
    },
};
