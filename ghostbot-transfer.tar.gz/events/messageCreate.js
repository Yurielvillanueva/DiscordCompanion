// Message create event - Handle incoming messages and commands
const logger = require('../utils/logger');
const config = require('../config');
const BotUtils = require('../bot');
const { storage } = require('../server/storage');

module.exports = {
    name: 'messageCreate',
    async execute(message) {
        // Ignore messages from bots and DMs
        if (message.author.bot || !message.guild) return;
        
        // Check if message starts with prefix
        if (!message.content.startsWith(config.prefix)) return;
        
        // Parse command and arguments
        const args = message.content.slice(config.prefix.length).trim().split(/ +/);
        const commandName = args.shift().toLowerCase();
        
        // Get command
        const command = message.client.commands.get(commandName);
        if (!command) return;
        
        try {
            // Ensure user exists in database
            let user = await storage.getUser(message.author.id);
            if (!user) {
                user = await storage.createUser({
                    discordId: message.author.id,
                    username: message.author.username,
                    discriminator: message.author.discriminator,
                    avatar: message.author.avatar
                });
            } else {
                // Update user info and last seen
                await storage.updateUser(message.author.id, {
                    username: message.author.username,
                    discriminator: message.author.discriminator,
                    avatar: message.author.avatar
                });
                await storage.updateUserLastSeen(message.author.id);
            }
            
            // Ensure guild exists in database
            let guild = await storage.getGuild(message.guild.id);
            if (!guild) {
                guild = await storage.createGuild({
                    guildId: message.guild.id,
                    name: message.guild.name,
                    icon: message.guild.icon,
                    ownerId: message.guild.ownerId,
                    memberCount: message.guild.memberCount
                });
            }
            
            // Log command usage
            logger.info(`Command "${commandName}" used by ${message.author.tag} (${message.author.id}) in ${message.guild.name} (${message.guild.id})`);
            
            // Execute command
            const success = await command.execute(message, args);
            
            // Log command to database
            await storage.logCommand({
                userId: user.id,
                guildId: guild.id,
                commandName: commandName,
                args: args.join(' ') || null,
                success: success !== false
            });
            
        } catch (error) {
            logger.error(`Error executing command "${commandName}":`, error);
            
            // Log failed command to database
            try {
                const user = await storage.getUser(message.author.id);
                const guild = await storage.getGuild(message.guild.id);
                if (user && guild) {
                    await storage.logCommand({
                        userId: user.id,
                        guildId: guild.id,
                        commandName: commandName,
                        args: args.join(' ') || null,
                        success: false,
                        errorMessage: error.message
                    });
                }
            } catch (logError) {
                logger.error('Failed to log command error:', logError);
            }
            
            const errorEmbed = BotUtils.createErrorEmbed(
                'An error occurred while executing this command. Please try again later.'
            );
            
            message.reply({ embeds: [errorEmbed] }).catch(replyError => {
                logger.error('Failed to send error message:', replyError);
            });
        }
    },
};
