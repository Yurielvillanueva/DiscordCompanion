import { pgTable, text, timestamp, integer, boolean, serial } from 'drizzle-orm/pg-core';
import { relations } from 'drizzle-orm';

// Users table - Store Discord user information
export const users = pgTable('users', {
  id: serial('id').primaryKey(),
  discordId: text('discord_id').unique().notNull(),
  username: text('username').notNull(),
  discriminator: text('discriminator'),
  avatar: text('avatar'),
  createdAt: timestamp('created_at').defaultNow().notNull(),
  updatedAt: timestamp('updated_at').defaultNow().notNull(),
  lastSeen: timestamp('last_seen').defaultNow().notNull(),
});

// Guilds table - Store Discord server information
export const guilds = pgTable('guilds', {
  id: serial('id').primaryKey(),
  guildId: text('guild_id').unique().notNull(),
  name: text('name').notNull(),
  icon: text('icon'),
  ownerId: text('owner_id').notNull(),
  memberCount: integer('member_count').default(0),
  prefix: text('prefix').default('!'),
  createdAt: timestamp('created_at').defaultNow().notNull(),
  updatedAt: timestamp('updated_at').defaultNow().notNull(),
});

// Guild members table - Track user membership in servers
export const guildMembers = pgTable('guild_members', {
  id: serial('id').primaryKey(),
  userId: integer('user_id').references(() => users.id).notNull(),
  guildId: integer('guild_id').references(() => guilds.id).notNull(),
  joinedAt: timestamp('joined_at').defaultNow().notNull(),
  isActive: boolean('is_active').default(true),
});

// Commands table - Track command usage
export const commandLogs = pgTable('command_logs', {
  id: serial('id').primaryKey(),
  userId: integer('user_id').references(() => users.id).notNull(),
  guildId: integer('guild_id').references(() => guilds.id).notNull(),
  commandName: text('command_name').notNull(),
  args: text('args'),
  executedAt: timestamp('executed_at').defaultNow().notNull(),
  success: boolean('success').default(true),
  errorMessage: text('error_message'),
});

// Moderation actions table - Track kicks, bans, etc.
export const moderationActions = pgTable('moderation_actions', {
  id: serial('id').primaryKey(),
  guildId: integer('guild_id').references(() => guilds.id).notNull(),
  moderatorId: integer('moderator_id').references(() => users.id).notNull(),
  targetId: integer('target_id').references(() => users.id).notNull(),
  action: text('action').notNull(), // 'kick', 'ban', 'unban', 'timeout'
  reason: text('reason'),
  duration: integer('duration'), // For timeouts, in minutes
  createdAt: timestamp('created_at').defaultNow().notNull(),
  isActive: boolean('is_active').default(true),
});

// Relations
export const usersRelations = relations(users, ({ many }) => ({
  guildMemberships: many(guildMembers),
  commandLogs: many(commandLogs),
  moderationActions: many(moderationActions),
  moderatedActions: many(moderationActions),
}));

export const guildsRelations = relations(guilds, ({ many }) => ({
  members: many(guildMembers),
  commandLogs: many(commandLogs),
  moderationActions: many(moderationActions),
}));

export const guildMembersRelations = relations(guildMembers, ({ one }) => ({
  user: one(users, {
    fields: [guildMembers.userId],
    references: [users.id],
  }),
  guild: one(guilds, {
    fields: [guildMembers.guildId],
    references: [guilds.id],
  }),
}));

export const commandLogsRelations = relations(commandLogs, ({ one }) => ({
  user: one(users, {
    fields: [commandLogs.userId],
    references: [users.id],
  }),
  guild: one(guilds, {
    fields: [commandLogs.guildId],
    references: [guilds.id],
  }),
}));

export const moderationActionsRelations = relations(moderationActions, ({ one }) => ({
  guild: one(guilds, {
    fields: [moderationActions.guildId],
    references: [guilds.id],
  }),
  moderator: one(users, {
    fields: [moderationActions.moderatorId],
    references: [users.id],
  }),
  target: one(users, {
    fields: [moderationActions.targetId],
    references: [users.id],
  }),
}));

// Types
export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;
export type Guild = typeof guilds.$inferSelect;
export type InsertGuild = typeof guilds.$inferInsert;
export type GuildMember = typeof guildMembers.$inferSelect;
export type InsertGuildMember = typeof guildMembers.$inferInsert;
export type CommandLog = typeof commandLogs.$inferSelect;
export type InsertCommandLog = typeof commandLogs.$inferInsert;
export type ModerationAction = typeof moderationActions.$inferSelect;
export type InsertModerationAction = typeof moderationActions.$inferInsert;