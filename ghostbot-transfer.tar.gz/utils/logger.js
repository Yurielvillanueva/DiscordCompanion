// Logging utility for the Discord bot
const fs = require('fs');
const path = require('path');

class Logger {
    constructor() {
        // Ensure logs directory exists
        this.logsDir = path.join(__dirname, '..', 'logs');
        if (!fs.existsSync(this.logsDir)) {
            fs.mkdirSync(this.logsDir, { recursive: true });
        }
        
        this.logFile = path.join(this.logsDir, `bot-${this.getDateString()}.log`);
    }
    
    /**
     * Get current date string for log files
     * @returns {string}
     */
    getDateString() {
        const now = new Date();
        return now.toISOString().split('T')[0]; // YYYY-MM-DD
    }
    
    /**
     * Get current timestamp
     * @returns {string}
     */
    getTimestamp() {
        return new Date().toISOString();
    }
    
    /**
     * Write log entry to file and console
     * @param {string} level - Log level
     * @param {string} message - Log message
     * @param {any} data - Additional data
     */
    writeLog(level, message, data = null) {
        const timestamp = this.getTimestamp();
        const logEntry = {
            timestamp,
            level: level.toUpperCase(),
            message,
            ...(data && { data })
        };
        
        // Console output with colors
        const colorCodes = {
            INFO: '\x1b[36m',    // Cyan
            WARN: '\x1b[33m',    // Yellow
            ERROR: '\x1b[31m',   // Red
            DEBUG: '\x1b[35m',   // Magenta
            RESET: '\x1b[0m'     // Reset
        };
        
        const color = colorCodes[level.toUpperCase()] || colorCodes.RESET;
        const consoleMessage = `${color}[${timestamp}] ${level.toUpperCase()}: ${message}${colorCodes.RESET}`;
        
        if (data) {
            console.log(consoleMessage, data);
        } else {
            console.log(consoleMessage);
        }
        
        // File output
        try {
            const fileEntry = JSON.stringify(logEntry) + '\n';
            fs.appendFileSync(this.logFile, fileEntry);
        } catch (error) {
            console.error('Failed to write to log file:', error);
        }
    }
    
    /**
     * Log info message
     * @param {string} message
     * @param {any} data
     */
    info(message, data = null) {
        this.writeLog('info', message, data);
    }
    
    /**
     * Log warning message
     * @param {string} message
     * @param {any} data
     */
    warn(message, data = null) {
        this.writeLog('warn', message, data);
    }
    
    /**
     * Log error message
     * @param {string} message
     * @param {any} data
     */
    error(message, data = null) {
        this.writeLog('error', message, data);
    }
    
    /**
     * Log debug message
     * @param {string} message
     * @param {any} data
     */
    debug(message, data = null) {
        this.writeLog('debug', message, data);
    }
    
    /**
     * Clean old log files (keep last 7 days)
     */
    cleanOldLogs() {
        try {
            const files = fs.readdirSync(this.logsDir);
            const now = new Date();
            const sevenDaysAgo = new Date(now.getTime() - (7 * 24 * 60 * 60 * 1000));
            
            files.forEach(file => {
                if (file.startsWith('bot-') && file.endsWith('.log')) {
                    const filePath = path.join(this.logsDir, file);
                    const stats = fs.statSync(filePath);
                    
                    if (stats.mtime < sevenDaysAgo) {
                        fs.unlinkSync(filePath);
                        this.info(`Cleaned old log file: ${file}`);
                    }
                }
            });
        } catch (error) {
            this.error('Error cleaning old logs:', error);
        }
    }
}

// Create and export logger instance
const logger = new Logger();

// Clean old logs on startup
logger.cleanOldLogs();

// Set up periodic log cleanup (daily)
setInterval(() => {
    logger.cleanOldLogs();
}, 24 * 60 * 60 * 1000);

module.exports = logger;
