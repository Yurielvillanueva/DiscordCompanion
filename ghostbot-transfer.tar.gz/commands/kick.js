// Kick command - Remove member from server
const { PermissionsBitField } = require('discord.js');
const BotUtils = require('../bot');
const { storage } = require('../server/storage');

module.exports = {
    name: 'kick',
    description: 'Kick a member from the server',
    usage: 'kick @user [reason]',
    execute(message, args) {
        // Check if user has kick permissions
        if (!message.member.permissions.has(PermissionsBitField.Flags.KickMembers)) {
            return message.reply({ 
                embeds: [BotUtils.createErrorEmbed('You need **Kick Members** permission to use this command.')] 
            });
        }

        // Check if bot has kick permissions
        if (!message.guild.members.me.permissions.has(PermissionsBitField.Flags.KickMembers)) {
            return message.reply({ 
                embeds: [BotUtils.createErrorEmbed('I need **Kick Members** permission to execute this command.')] 
            });
        }

        if (!args.length) {
            return message.reply({ 
                embeds: [BotUtils.createErrorEmbed('Please mention a user to kick.')] 
            });
        }

        const target = message.mentions.members.first();
        if (!target) {
            return message.reply({ 
                embeds: [BotUtils.createErrorEmbed('Please mention a valid user.')] 
            });
        }

        // Check if target is kickable
        if (!target.kickable) {
            return message.reply({ 
                embeds: [BotUtils.createErrorEmbed('I cannot kick this user. They may have higher permissions.')] 
            });
        }

        // Check role hierarchy
        if (target.roles.highest.position >= message.member.roles.highest.position) {
            return message.reply({ 
                embeds: [BotUtils.createErrorEmbed('You cannot kick someone with equal or higher role than you.')] 
            });
        }

        // Get reason
        const reason = args.slice(1).join(' ') || 'No reason provided';

        // Attempt to kick
        target.kick(reason)
            .then(async () => {
                // Log moderation action to database
                try {
                    const moderator = await storage.getUser(message.author.id);
                    const targetUser = await storage.getUser(target.user.id);
                    const guild = await storage.getGuild(message.guild.id);
                    
                    if (moderator && targetUser && guild) {
                        await storage.logModerationAction({
                            guildId: guild.id,
                            moderatorId: moderator.id,
                            targetId: targetUser.id,
                            action: 'kick',
                            reason: reason
                        });
                    }
                } catch (dbError) {
                    console.error('Failed to log kick action:', dbError);
                }
                
                const embed = BotUtils.createSuccessEmbed(
                    `Successfully kicked **${target.user.tag}**\n**Reason:** ${reason}`
                );
                message.reply({ embeds: [embed] });
            })
            .catch(error => {
                console.error('Error kicking user:', error);
                message.reply({ 
                    embeds: [BotUtils.createErrorEmbed('Failed to kick the user. Please try again.')] 
                });
            });
    },
};
