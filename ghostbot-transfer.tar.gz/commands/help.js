// Help command - Display available commands
const { EmbedBuilder } = require('discord.js');
const BotUtils = require('../bot');
const config = require('../config');

module.exports = {
    name: 'help',
    description: 'Display all available commands',
    usage: `help [command]`,
    execute(message, args) {
        const { commands } = message.client;
        
        if (!args.length) {
            // Display all commands
            const embed = new EmbedBuilder()
                .setTitle('📚 Available Commands')
                .setDescription(`Use \`${config.prefix}help [command]\` for detailed information about a specific command.`)
                .setColor('#0099ff')
                .setTimestamp()
                .setFooter({ 
                    text: `${config.botName} | Total Commands: ${commands.size}`,
                    iconURL: 'https://cdn.jsdelivr.net/gh/devicons/devicon/icons/javascript/javascript-original.svg'
                });

            // Group commands by category
            const generalCommands = [];
            const moderationCommands = [];
            const utilityCommands = [];

            commands.forEach(command => {
                const commandInfo = `\`${config.prefix}${command.usage || command.name}\` - ${command.description}`;
                
                if (['kick', 'ban', 'clear'].includes(command.name)) {
                    moderationCommands.push(commandInfo);
                } else if (['userinfo'].includes(command.name)) {
                    utilityCommands.push(commandInfo);
                } else {
                    generalCommands.push(commandInfo);
                }
            });

            if (generalCommands.length > 0) {
                embed.addFields({ name: '🔧 General Commands', value: generalCommands.join('\n'), inline: false });
            }
            
            if (moderationCommands.length > 0) {
                embed.addFields({ name: '🛡️ Moderation Commands', value: moderationCommands.join('\n'), inline: false });
            }
            
            if (utilityCommands.length > 0) {
                embed.addFields({ name: '📊 Utility Commands', value: utilityCommands.join('\n'), inline: false });
            }

            return message.reply({ embeds: [embed] });
        }

        // Display specific command help
        const commandName = args[0].toLowerCase();
        const command = commands.get(commandName);

        if (!command) {
            return message.reply({ 
                embeds: [BotUtils.createErrorEmbed(`Command \`${commandName}\` not found.`)] 
            });
        }

        const embed = BotUtils.createEmbed(
            `📖 Command: ${command.name}`,
            `**Description:** ${command.description}\n**Usage:** \`${config.prefix}${command.usage || command.name}\``,
            '#0099ff'
        );

        message.reply({ embeds: [embed] });
    },
};
