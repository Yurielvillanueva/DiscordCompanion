// Stats command - Display database statistics
const { EmbedBuilder } = require('discord.js');
const BotUtils = require('../bot');
const { storage } = require('../server/storage');

module.exports = {
    name: 'stats',
    description: 'Display bot and database statistics',
    usage: 'stats',
    async execute(message, args) {
        try {
            // Get database stats
            const guild = await storage.getGuild(message.guild.id);
            if (!guild) {
                return message.reply({ 
                    embeds: [BotUtils.createErrorEmbed('Guild not found in database.')] 
                });
            }

            const commandHistory = await storage.getCommandHistory(0, guild.id, 1000);
            const moderationHistory = await storage.getModerationHistory(guild.id, 1000);
            
            // Calculate command usage stats
            const commandStats = {};
            let totalCommands = 0;
            let successfulCommands = 0;
            
            commandHistory.forEach(log => {
                if (log.guildId === guild.id) {
                    totalCommands++;
                    if (log.success) successfulCommands++;
                    
                    if (commandStats[log.commandName]) {
                        commandStats[log.commandName]++;
                    } else {
                        commandStats[log.commandName] = 1;
                    }
                }
            });
            
            // Get top 5 commands
            const topCommands = Object.entries(commandStats)
                .sort((a, b) => b[1] - a[1])
                .slice(0, 5)
                .map(([cmd, count]) => `${cmd}: ${count}`)
                .join('\n') || 'No commands used yet';
            
            // Calculate moderation stats
            const moderationStats = {};
            moderationHistory.forEach(action => {
                if (moderationStats[action.action]) {
                    moderationStats[action.action]++;
                } else {
                    moderationStats[action.action] = 1;
                }
            });
            
            const moderationText = Object.entries(moderationStats)
                .map(([action, count]) => `${action}: ${count}`)
                .join('\n') || 'No moderation actions yet';

            // Bot uptime
            const uptime = BotUtils.formatUptime(message.client.uptime);
            
            // Memory usage
            const memUsage = process.memoryUsage();
            const memoryText = `${Math.round(memUsage.heapUsed / 1024 / 1024)}MB / ${Math.round(memUsage.heapTotal / 1024 / 1024)}MB`;

            const embed = new EmbedBuilder()
                .setTitle('📊 Bot Statistics')
                .setColor('#0099ff')
                .setTimestamp()
                .setThumbnail(message.client.user.displayAvatarURL())
                .setFooter({ 
                    text: `${message.client.user.tag} | Database Connected`,
                    iconURL: 'https://cdn.jsdelivr.net/gh/devicons/devicon/icons/postgresql/postgresql-original.svg'
                });

            // Bot stats
            embed.addFields(
                { name: '🤖 Bot Info', value: `**Uptime:** ${uptime}\n**Memory:** ${memoryText}\n**Guilds:** ${message.client.guilds.cache.size}`, inline: true },
                { name: '📈 Performance', value: `**Commands:** ${totalCommands}\n**Success Rate:** ${totalCommands > 0 ? Math.round((successfulCommands / totalCommands) * 100) : 0}%\n**Moderations:** ${moderationHistory.length}`, inline: true },
                { name: '🏆 Top Commands', value: topCommands, inline: false }
            );

            if (moderationHistory.length > 0) {
                embed.addFields({ name: '🛡️ Moderation Actions', value: moderationText, inline: false });
            }

            // Guild specific info
            embed.addFields(
                { name: '🏠 This Server', value: `**Name:** ${message.guild.name}\n**Members:** ${message.guild.memberCount}\n**Created:** <t:${Math.floor(message.guild.createdTimestamp / 1000)}:R>`, inline: true }
            );

            message.reply({ embeds: [embed] });
            
        } catch (error) {
            console.error('Error in stats command:', error);
            message.reply({ 
                embeds: [BotUtils.createErrorEmbed('Failed to fetch statistics. Please try again.')] 
            });
        }
    },
};