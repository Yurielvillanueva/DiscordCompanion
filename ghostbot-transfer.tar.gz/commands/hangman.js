// Hangman command - Interactive hangman game
const { EmbedBuilder } = require('discord.js');
const BotUtils = require('../bot');
const { storage } = require('../server/storage');

// Store active games per channel
const activeGames = new Map();

module.exports = {
    name: 'hangman',
    description: 'Start a hangman guessing game in the channel',
    usage: 'hangman [new/guess/stop] [letter]',
    async execute(message, args) {
        try {
            const subcommand = args[0]?.toLowerCase();
            const channelId = message.channel.id;

            if (subcommand === 'stop' || subcommand === 'end') {
                return stopGame(message, channelId);
            }

            if (subcommand === 'guess' || subcommand === 'g') {
                return makeGuess(message, args[1], channelId);
            }

            // Default action: start new game or show current game
            if (!activeGames.has(channelId) || subcommand === 'new') {
                return startNewGame(message, channelId);
            } else {
                return showCurrentGame(message, channelId);
            }

        } catch (error) {
            console.error('Error in hangman command:', error);
            message.reply({ 
                embeds: [BotUtils.createErrorEmbed('Something went wrong with the hangman game. Please try again.')] 
            });
        }
    },
};

function startNewGame(message, channelId) {
    const words = [
        'JAVASCRIPT', 'DISCORD', 'COMPUTER', 'KEYBOARD', 'INTERNET', 'PROGRAMMING',
        'REPLIT', 'CODING', 'WEBSITE', 'SERVER', 'DATABASE', 'FUNCTION',
        'VARIABLE', 'BOOLEAN', 'STRING', 'NUMBER', 'ARRAY', 'OBJECT',
        'DRAGON', 'CASTLE', 'WIZARD', 'MAGIC', 'ADVENTURE', 'TREASURE',
        'RAINBOW', 'BUTTERFLY', 'MOUNTAIN', 'OCEAN', 'FOREST', 'SUNSET',
        'GALAXY', 'PLANET', 'ROCKET', 'ASTRONAUT', 'ALIEN', 'SPACESHIP',
        'PIZZA', 'BURGER', 'CHOCOLATE', 'COOKIE', 'SANDWICH', 'COFFEE'
    ];

    const selectedWord = words[Math.floor(Math.random() * words.length)];
    
    const gameState = {
        word: selectedWord,
        guessedLetters: [],
        wrongGuesses: [],
        maxWrongGuesses: 6,
        gameStarted: new Date(),
        startedBy: message.author.id
    };

    activeGames.set(channelId, gameState);
    
    displayGame(message, gameState, "🎮 New Hangman Game Started!");
    logCommand(message, 'hangman', ['new']);
}

function makeGuess(message, letter, channelId) {
    const game = activeGames.get(channelId);
    
    if (!game) {
        return message.reply({ 
            embeds: [BotUtils.createErrorEmbed('No active hangman game! Use `!hangman` to start one.')] 
        });
    }

    if (!letter || letter.length !== 1 || !/[A-Za-z]/.test(letter)) {
        return message.reply({ 
            embeds: [BotUtils.createErrorEmbed('Please guess a single letter. Example: `!hangman guess A`')] 
        });
    }

    const guessedLetter = letter.toUpperCase();
    
    // Check if already guessed
    if (game.guessedLetters.includes(guessedLetter) || game.wrongGuesses.includes(guessedLetter)) {
        return message.reply({ 
            embeds: [BotUtils.createWarningEmbed(`Letter **${guessedLetter}** has already been guessed!`)] 
        });
    }

    // Process guess
    if (game.word.includes(guessedLetter)) {
        game.guessedLetters.push(guessedLetter);
        
        // Check if word is complete
        const isComplete = game.word.split('').every(letter => game.guessedLetters.includes(letter));
        
        if (isComplete) {
            activeGames.delete(channelId);
            displayWin(message, game, guessedLetter);
        } else {
            displayGame(message, game, `✅ Good guess! **${guessedLetter}** is in the word!`);
        }
    } else {
        game.wrongGuesses.push(guessedLetter);
        
        // Check if game is over
        if (game.wrongGuesses.length >= game.maxWrongGuesses) {
            activeGames.delete(channelId);
            displayLoss(message, game, guessedLetter);
        } else {
            displayGame(message, game, `❌ Sorry! **${guessedLetter}** is not in the word.`);
        }
    }

    logCommand(message, 'hangman', ['guess', guessedLetter]);
}

function stopGame(message, channelId) {
    const game = activeGames.get(channelId);
    
    if (!game) {
        return message.reply({ 
            embeds: [BotUtils.createErrorEmbed('No active hangman game to stop.')] 
        });
    }

    activeGames.delete(channelId);
    
    const embed = new EmbedBuilder()
        .setTitle('🛑 Hangman Game Stopped')
        .setDescription(`Game ended by ${message.author.username}\n\nThe word was: **${game.word}**`)
        .setColor('#FF4500')
        .setTimestamp();

    message.reply({ embeds: [embed] });
    logCommand(message, 'hangman', ['stop']);
}

function showCurrentGame(message, channelId) {
    const game = activeGames.get(channelId);
    
    if (!game) {
        return message.reply({ 
            embeds: [BotUtils.createErrorEmbed('No active hangman game! Use `!hangman` to start one.')] 
        });
    }

    displayGame(message, game, "📋 Current Hangman Game");
}

function displayGame(message, game, title) {
    const displayWord = game.word
        .split('')
        .map(letter => game.guessedLetters.includes(letter) ? letter : '_')
        .join(' ');

    const hangmanArt = getHangmanArt(game.wrongGuesses.length);
    
    const embed = new EmbedBuilder()
        .setTitle(title)
        .setDescription(`\`\`\`${hangmanArt}\`\`\``)
        .addFields([
            { name: '📝 Word', value: `\`${displayWord}\``, inline: false },
            { name: '✅ Correct Letters', value: game.guessedLetters.length > 0 ? game.guessedLetters.join(', ') : 'None', inline: true },
            { name: '❌ Wrong Letters', value: game.wrongGuesses.length > 0 ? game.wrongGuesses.join(', ') : 'None', inline: true },
            { name: '❤️ Lives Left', value: `${game.maxWrongGuesses - game.wrongGuesses.length}/${game.maxWrongGuesses}`, inline: true }
        ])
        .setColor('#4169E1')
        .setTimestamp()
        .setFooter({ 
            text: 'Use !hangman guess [letter] to make a guess • !hangman stop to end game',
            iconURL: 'https://cdn.jsdelivr.net/gh/devicons/devicon/icons/javascript/javascript-original.svg'
        });

    message.reply({ embeds: [embed] });
}

function displayWin(message, game, finalLetter) {
    const embed = new EmbedBuilder()
        .setTitle('🎉 Congratulations! You Won!')
        .setDescription(`**${finalLetter}** was correct!\n\nThe word was: **${game.word}**`)
        .addFields([
            { name: '🎯 Total Guesses', value: `${game.guessedLetters.length + game.wrongGuesses.length}`, inline: true },
            { name: '❌ Wrong Guesses', value: `${game.wrongGuesses.length}/${game.maxWrongGuesses}`, inline: true },
            { name: '⏱️ Game Duration', value: `${Math.round((new Date() - game.gameStarted) / 1000)} seconds`, inline: true }
        ])
        .setColor('#00FF00')
        .setTimestamp();

    message.reply({ embeds: [embed] });
}

function displayLoss(message, game, finalLetter) {
    const hangmanArt = getHangmanArt(game.maxWrongGuesses);
    
    const embed = new EmbedBuilder()
        .setTitle('💀 Game Over!')
        .setDescription(`\`\`\`${hangmanArt}\`\`\`\n**${finalLetter}** was wrong!\n\nThe word was: **${game.word}**`)
        .addFields([
            { name: '✅ Correct Letters', value: game.guessedLetters.length > 0 ? game.guessedLetters.join(', ') : 'None', inline: true },
            { name: '❌ Wrong Letters', value: game.wrongGuesses.join(', '), inline: true },
            { name: '⏱️ Game Duration', value: `${Math.round((new Date() - game.gameStarted) / 1000)} seconds`, inline: true }
        ])
        .setColor('#FF0000')
        .setTimestamp()
        .setFooter({ text: 'Better luck next time! Use !hangman to start a new game' });

    message.reply({ embeds: [embed] });
}

function getHangmanArt(wrongGuesses) {
    const stages = [
        // 0 wrong guesses
        `  +---+
  |   |
      |
      |
      |
      |
=========`,
        // 1 wrong guess
        `  +---+
  |   |
  O   |
      |
      |
      |
=========`,
        // 2 wrong guesses
        `  +---+
  |   |
  O   |
  |   |
      |
      |
=========`,
        // 3 wrong guesses
        `  +---+
  |   |
  O   |
 /|   |
      |
      |
=========`,
        // 4 wrong guesses
        `  +---+
  |   |
  O   |
 /|\\  |
      |
      |
=========`,
        // 5 wrong guesses
        `  +---+
  |   |
  O   |
 /|\\  |
 /    |
      |
=========`,
        // 6 wrong guesses (game over)
        `  +---+
  |   |
  O   |
 /|\\  |
 / \\  |
      |
=========`
    ];

    return stages[Math.min(wrongGuesses, stages.length - 1)];
}

async function logCommand(message, commandName, args) {
    try {
        let user = await storage.getUser(message.author.id);
        if (!user) {
            user = await storage.createUser({
                discordId: message.author.id,
                username: message.author.username,
                discriminator: message.author.discriminator,
                avatar: message.author.avatar
            });
        }

        let guild = await storage.getGuild(message.guild.id);
        if (!guild) {
            guild = await storage.createGuild({
                guildId: message.guild.id,
                name: message.guild.name,
                icon: message.guild.icon,
                ownerId: message.guild.ownerId,
                memberCount: message.guild.memberCount
            });
        }

        await storage.logCommand({
            userId: user.id,
            guildId: guild.id,
            commandName,
            args,
            channelId: message.channel.id,
            messageId: message.id,
            success: true
        });
    } catch (error) {
        console.error('Error logging command:', error);
    }
}