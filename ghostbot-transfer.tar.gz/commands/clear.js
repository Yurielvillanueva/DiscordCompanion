// Clear command - Bulk delete messages
const { PermissionsBitField } = require('discord.js');
const BotUtils = require('../bot');

module.exports = {
    name: 'clear',
    description: 'Clear a specified number of messages',
    usage: 'clear <amount>',
    execute(message, args) {
        // Check if user has manage messages permission
        if (!message.member.permissions.has(PermissionsBitField.Flags.ManageMessages)) {
            return message.reply({ 
                embeds: [BotUtils.createErrorEmbed('You need **Manage Messages** permission to use this command.')] 
            });
        }

        // Check if bot has manage messages permission
        if (!message.guild.members.me.permissions.has(PermissionsBitField.Flags.ManageMessages)) {
            return message.reply({ 
                embeds: [BotUtils.createErrorEmbed('I need **Manage Messages** permission to execute this command.')] 
            });
        }

        if (!args.length) {
            return message.reply({ 
                embeds: [BotUtils.createErrorEmbed('Please specify the number of messages to clear.')] 
            });
        }

        const amount = parseInt(args[0]);

        if (isNaN(amount) || amount <= 0 || amount > 100) {
            return message.reply({ 
                embeds: [BotUtils.createErrorEmbed('Please provide a number between 1 and 100.')] 
            });
        }

        // Add 1 to include the command message itself
        const deleteAmount = amount + 1;

        message.channel.bulkDelete(deleteAmount, true)
            .then(deleted => {
                const actualDeleted = deleted.size - 1; // Subtract the command message
                const embed = BotUtils.createSuccessEmbed(
                    `Successfully cleared **${actualDeleted}** message${actualDeleted !== 1 ? 's' : ''}.`
                );
                
                // Send confirmation and delete it after 5 seconds
                message.channel.send({ embeds: [embed] })
                    .then(msg => {
                        setTimeout(() => {
                            msg.delete().catch(() => {});
                        }, 5000);
                    });
            })
            .catch(error => {
                console.error('Error clearing messages:', error);
                message.reply({ 
                    embeds: [BotUtils.createErrorEmbed('Failed to clear messages. Messages may be too old (older than 14 days).')] 
                });
            });
    },
};
