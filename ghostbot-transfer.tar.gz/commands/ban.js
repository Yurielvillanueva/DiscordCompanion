// Ban command - Ban member from server
const { PermissionsBitField } = require('discord.js');
const BotUtils = require('../bot');
const { storage } = require('../server/storage');

module.exports = {
    name: 'ban',
    description: 'Ban a member from the server',
    usage: 'ban @user [reason]',
    execute(message, args) {
        // Check if user has ban permissions
        if (!message.member.permissions.has(PermissionsBitField.Flags.BanMembers)) {
            return message.reply({ 
                embeds: [BotUtils.createErrorEmbed('You need **Ban Members** permission to use this command.')] 
            });
        }

        // Check if bot has ban permissions
        if (!message.guild.members.me.permissions.has(PermissionsBitField.Flags.BanMembers)) {
            return message.reply({ 
                embeds: [BotUtils.createErrorEmbed('I need **Ban Members** permission to execute this command.')] 
            });
        }

        if (!args.length) {
            return message.reply({ 
                embeds: [BotUtils.createErrorEmbed('Please mention a user to ban.')] 
            });
        }

        const target = message.mentions.members.first();
        if (!target) {
            return message.reply({ 
                embeds: [BotUtils.createErrorEmbed('Please mention a valid user.')] 
            });
        }

        // Check if target is bannable
        if (!target.bannable) {
            return message.reply({ 
                embeds: [BotUtils.createErrorEmbed('I cannot ban this user. They may have higher permissions.')] 
            });
        }

        // Check role hierarchy
        if (target.roles.highest.position >= message.member.roles.highest.position) {
            return message.reply({ 
                embeds: [BotUtils.createErrorEmbed('You cannot ban someone with equal or higher role than you.')] 
            });
        }

        // Get reason
        const reason = args.slice(1).join(' ') || 'No reason provided';

        // Attempt to ban
        target.ban({ reason, deleteMessageDays: 1 })
            .then(async () => {
                // Log moderation action to database
                try {
                    const moderator = await storage.getUser(message.author.id);
                    const targetUser = await storage.getUser(target.user.id);
                    const guild = await storage.getGuild(message.guild.id);
                    
                    if (moderator && targetUser && guild) {
                        await storage.logModerationAction({
                            guildId: guild.id,
                            moderatorId: moderator.id,
                            targetId: targetUser.id,
                            action: 'ban',
                            reason: reason
                        });
                    }
                } catch (dbError) {
                    console.error('Failed to log ban action:', dbError);
                }
                
                const embed = BotUtils.createSuccessEmbed(
                    `Successfully banned **${target.user.tag}**\n**Reason:** ${reason}`
                );
                message.reply({ embeds: [embed] });
            })
            .catch(error => {
                console.error('Error banning user:', error);
                message.reply({ 
                    embeds: [BotUtils.createErrorEmbed('Failed to ban the user. Please try again.')] 
                });
            });
    },
};
