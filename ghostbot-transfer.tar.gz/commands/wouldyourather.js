// Would You Rather command - Sends random "Would You Rather" questions
const { EmbedBuilder } = require('discord.js');
const BotUtils = require('../bot');
const { storage } = require('../server/storage');

module.exports = {
    name: 'wouldyourather',
    description: 'Get a random "Would You Rather" question to debate',
    usage: 'wouldyourather',
    async execute(message, args) {
        try {
            // Array of Would You Rather questions
            const questions = [
                {
                    optionA: "Have the ability to fly",
                    optionB: "Have the ability to read minds",
                    category: "Superpowers"
                },
                {
                    optionA: "Always be 10 minutes late",
                    optionB: "Always be 20 minutes early",
                    category: "Time"
                },
                {
                    optionA: "Live without music",
                    optionB: "Live without movies/TV",
                    category: "Entertainment"
                },
                {
                    optionA: "Have unlimited money but no friends",
                    optionB: "Have amazing friends but struggle financially",
                    category: "Life Choice"
                },
                {
                    optionA: "Be able to speak any language fluently",
                    optionB: "Be able to play any musical instrument perfectly",
                    category: "Skills"
                },
                {
                    optionA: "Always know when someone is lying",
                    optionB: "Always get away with lying",
                    category: "Truth"
                },
                {
                    optionA: "Have the best house in a bad neighborhood",
                    optionB: "Have the worst house in a great neighborhood",
                    category: "Living"
                },
                {
                    optionA: "Only be able to whisper",
                    optionB: "Only be able to shout",
                    category: "Communication"
                },
                {
                    optionA: "Have your thoughts appear as text above your head",
                    optionB: "Hear everyone else's thoughts",
                    category: "Mind Reading"
                },
                {
                    optionA: "Be famous for something embarrassing",
                    optionB: "Be unknown but respected by close friends",
                    category: "Fame"
                },
                {
                    optionA: "Always have to dance when you hear music",
                    optionB: "Never be able to dance again",
                    category: "Movement"
                },
                {
                    optionA: "Live in a world without pizza",
                    optionB: "Live in a world without ice cream",
                    category: "Food"
                },
                {
                    optionA: "Have unlimited Wi-Fi everywhere but no devices",
                    optionB: "Have amazing devices but no internet",
                    category: "Technology"
                },
                {
                    optionA: "Always feel like you have to sneeze but can't",
                    optionB: "Always have something stuck in your teeth",
                    category: "Annoying"
                },
                {
                    optionA: "Be able to time travel but only to the past",
                    optionB: "Be able to time travel but only to the future",
                    category: "Time Travel"
                },
                {
                    optionA: "Have unlimited battery life on all devices",
                    optionB: "Never have to sleep again",
                    category: "Modern Life"
                },
                {
                    optionA: "Always have perfect weather wherever you go",
                    optionB: "Never get sick again",
                    category: "Life Quality"
                },
                {
                    optionA: "Only be able to eat sweet foods",
                    optionB: "Only be able to eat salty foods",
                    category: "Diet"
                },
                {
                    optionA: "Be incredibly intelligent but socially awkward",
                    optionB: "Be average intelligence but extremely charismatic",
                    category: "Personality"
                },
                {
                    optionA: "Live in a mansion but be completely alone",
                    optionB: "Live in a tiny apartment with your favorite people",
                    category: "Social"
                }
            ];

            // Select random question
            const randomQuestion = questions[Math.floor(Math.random() * questions.length)];
            
            // Create embed
            const embed = new EmbedBuilder()
                .setTitle('🤔 Would You Rather?')
                .setDescription('**Choose your option and debate in the chat!**')
                .addFields([
                    { name: '🅰️ Option A', value: randomQuestion.optionA, inline: true },
                    { name: '🅱️ Option B', value: randomQuestion.optionB, inline: true },
                    { name: '📂 Category', value: randomQuestion.category, inline: false }
                ])
                .setColor('#FF6B6B')
                .setTimestamp()
                .setFooter({ 
                    text: `${message.client.user.tag} • React with 🅰️ or 🅱️ to vote!`,
                    iconURL: 'https://cdn.jsdelivr.net/gh/devicons/devicon/icons/javascript/javascript-original.svg'
                });

            // Send message
            const sentMessage = await message.reply({ embeds: [embed] });
            
            // Add reaction options for voting
            await sentMessage.react('🅰️');
            await sentMessage.react('🅱️');

            // Log command
            await logCommand(message, 'wouldyourather', [randomQuestion.category]);

        } catch (error) {
            console.error('Error in wouldyourather command:', error);
            message.reply({ 
                embeds: [BotUtils.createErrorEmbed('Failed to generate Would You Rather question. Please try again.')] 
            });
        }
    },
};

async function logCommand(message, commandName, args) {
    try {
        let user = await storage.getUser(message.author.id);
        if (!user) {
            user = await storage.createUser({
                discordId: message.author.id,
                username: message.author.username,
                discriminator: message.author.discriminator,
                avatar: message.author.avatar
            });
        }

        let guild = await storage.getGuild(message.guild.id);
        if (!guild) {
            guild = await storage.createGuild({
                guildId: message.guild.id,
                name: message.guild.name,
                icon: message.guild.icon,
                ownerId: message.guild.ownerId,
                memberCount: message.guild.memberCount
            });
        }

        await storage.logCommand({
            userId: user.id,
            guildId: guild.id,
            commandName,
            args,
            channelId: message.channel.id,
            messageId: message.id,
            success: true
        });
    } catch (error) {
        console.error('Error logging command:', error);
    }
}