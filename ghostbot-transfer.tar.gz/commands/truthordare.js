// Truth or Dare command - Random truth questions or dares
const { EmbedBuilder } = require('discord.js');
const BotUtils = require('../bot');
const { storage } = require('../server/storage');

module.exports = {
    name: 'truthordare',
    description: 'Get a random truth question or dare challenge',
    usage: 'truthordare [truth/dare] or just truthordare for random',
    async execute(message, args) {
        try {
            let selectedType = args[0]?.toLowerCase();
            
            // If no type specified or invalid type, randomly choose
            if (!selectedType || !['truth', 'dare'].includes(selectedType)) {
                selectedType = Math.random() < 0.5 ? 'truth' : 'dare';
            }

            const questions = {
                truth: [
                    "What's the most embarrassing thing you've ever done?",
                    "What's your biggest fear that you've never told anyone?",
                    "If you could switch lives with someone for a day, who would it be?",
                    "What's the weirdest dream you've ever had?",
                    "What's something you're glad your parents don't know about you?",
                    "What's the most childish thing you still do?",
                    "What's your most unpopular opinion?",
                    "What's the worst lie you've ever told?",
                    "What's something you've never told your best friend?",
                    "If you could erase one past experience, what would it be?",
                    "What's the most trouble you've ever gotten into?",
                    "What's your guilty pleasure that you're ashamed of?",
                    "Who in this server do you think is the most attractive?",
                    "What's the strangest thing you believed as a child?",
                    "What's your most cringe social media post?",
                    "What's something you've done that you hope no one finds out?",
                    "What's the worst advice you've ever given?",
                    "What's your biggest regret in life so far?",
                    "What's the meanest thing you've ever said to someone?",
                    "What's something everyone else loves but you hate?"
                ],
                dare: [
                    "Send a voice message singing your favorite song",
                    "Change your Discord status to something embarrassing for 1 hour",
                    "Share an embarrassing photo from your camera roll",
                    "Do 20 push-ups and post a video",
                    "Text your crush or post 'I have a crush on someone' in general chat",
                    "Change your nickname to 'I lost a dare' for 24 hours",
                    "Share the last 5 photos in your camera roll",
                    "Record yourself doing your best impression of another server member",
                    "Let someone else write your Discord status for the rest of the day",
                    "Post an embarrassing childhood story",
                    "Do your best dance and post a video",
                    "Speak in rhymes for the next 10 messages",
                    "Share your most embarrassing autocorrect fail",
                    "Let the server choose your profile picture for a week",
                    "Post a selfie with the weirdest face you can make",
                    "Eat something weird and record your reaction",
                    "Call someone random and sing Happy Birthday",
                    "Share your browser history from today",
                    "Post your most embarrassing DM (with names blocked)",
                    "Pretend to be a bot for the next 30 minutes in chat"
                ]
            };

            const selectedQuestion = questions[selectedType][Math.floor(Math.random() * questions[selectedType].length)];
            
            // Create embed
            const embed = new EmbedBuilder()
                .setTitle(`${selectedType === 'truth' ? '🕵️' : '💀'} ${selectedType.toUpperCase()}`)
                .setDescription(`**${message.author.username}, here's your ${selectedType}:**\n\n${selectedQuestion}`)
                .setColor(selectedType === 'truth' ? '#4169E1' : '#DC143C')
                .setTimestamp()
                .setThumbnail(message.author.displayAvatarURL())
                .setFooter({ 
                    text: `${message.client.user.tag} • Use !truthordare truth or !truthordare dare for specific type`,
                    iconURL: 'https://cdn.jsdelivr.net/gh/devicons/devicon/icons/javascript/javascript-original.svg'
                });

            // Add some reactions for fun
            const sentMessage = await message.reply({ embeds: [embed] });
            
            if (selectedType === 'truth') {
                await sentMessage.react('🤔');
                await sentMessage.react('😬');
            } else {
                await sentMessage.react('😈');
                await sentMessage.react('💪');
            }

            // Log command
            await logCommand(message, 'truthordare', [selectedType]);

        } catch (error) {
            console.error('Error in truthordare command:', error);
            message.reply({ 
                embeds: [BotUtils.createErrorEmbed('Failed to generate truth or dare. Please try again.')] 
            });
        }
    },
};

async function logCommand(message, commandName, args) {
    try {
        let user = await storage.getUser(message.author.id);
        if (!user) {
            user = await storage.createUser({
                discordId: message.author.id,
                username: message.author.username,
                discriminator: message.author.discriminator,
                avatar: message.author.avatar
            });
        }

        let guild = await storage.getGuild(message.guild.id);
        if (!guild) {
            guild = await storage.createGuild({
                guildId: message.guild.id,
                name: message.guild.name,
                icon: message.guild.icon,
                ownerId: message.guild.ownerId,
                memberCount: message.guild.memberCount
            });
        }

        await storage.logCommand({
            userId: user.id,
            guildId: guild.id,
            commandName,
            args,
            channelId: message.channel.id,
            messageId: message.id,
            success: true
        });
    } catch (error) {
        console.error('Error logging command:', error);
    }
}