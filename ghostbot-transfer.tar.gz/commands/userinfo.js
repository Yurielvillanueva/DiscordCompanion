// User info command - Display user information
const { EmbedBuilder } = require('discord.js');
const BotUtils = require('../bot');

module.exports = {
    name: 'userinfo',
    description: 'Display information about a user',
    usage: 'userinfo [@user]',
    execute(message, args) {
        // Get target user (mentioned user or message author)
        const target = message.mentions.members.first() || message.member;
        const user = target.user;

        // Calculate account age
        const accountAge = Math.floor((Date.now() - user.createdTimestamp) / (1000 * 60 * 60 * 24));
        
        // Calculate server join age
        const joinAge = Math.floor((Date.now() - target.joinedTimestamp) / (1000 * 60 * 60 * 24));

        // Get user roles (exclude @everyone)
        const roles = target.roles.cache
            .filter(role => role.name !== '@everyone')
            .map(role => role.toString())
            .slice(0, 10); // Limit to 10 roles to avoid embed limits

        const embed = new EmbedBuilder()
            .setTitle(`👤 User Information: ${user.tag}`)
            .setThumbnail(user.displayAvatarURL({ dynamic: true, size: 256 }))
            .setColor(target.displayHexColor || '#0099ff')
            .setTimestamp()
            .setFooter({ 
                text: `ID: ${user.id}`,
                iconURL: 'https://cdn.jsdelivr.net/gh/devicons/devicon/icons/javascript/javascript-original.svg'
            });

        // Basic user info
        embed.addFields(
            { name: '🏷️ Username', value: user.username, inline: true },
            { name: '🔢 Discriminator', value: user.discriminator || 'None', inline: true },
            { name: '📛 Display Name', value: target.displayName || 'None', inline: true }
        );

        // Account dates
        embed.addFields(
            { name: '📅 Account Created', value: `<t:${Math.floor(user.createdTimestamp / 1000)}:F>\n(${accountAge} days ago)`, inline: true },
            { name: '📥 Joined Server', value: `<t:${Math.floor(target.joinedTimestamp / 1000)}:F>\n(${joinAge} days ago)`, inline: true },
            { name: '🎭 Status', value: target.presence?.status || 'offline', inline: true }
        );

        // User flags and badges
        const flags = user.flags?.toArray() || [];
        if (flags.length > 0) {
            const flagsFormatted = flags.map(flag => {
                switch (flag) {
                    case 'Staff': return '👑 Discord Staff';
                    case 'Partner': return '🤝 Discord Partner';
                    case 'Hypesquad': return '🎉 HypeSquad Events';
                    case 'BugHunterLevel1': return '🐛 Bug Hunter';
                    case 'BugHunterLevel2': return '🐛 Bug Hunter Level 2';
                    case 'HypesquadOnlineHouse1': return '⚡ HypeSquad Bravery';
                    case 'HypesquadOnlineHouse2': return '💎 HypeSquad Brilliance';
                    case 'HypesquadOnlineHouse3': return '🎯 HypeSquad Balance';
                    case 'PremiumEarlySupporter': return '💎 Early Nitro Supporter';
                    case 'VerifiedDeveloper': return '🔨 Verified Bot Developer';
                    default: return flag;
                }
            }).join('\n');
            
            embed.addFields({ name: '🏆 Badges', value: flagsFormatted, inline: false });
        }

        // Roles
        if (roles.length > 0) {
            const roleText = roles.length > 10 
                ? `${roles.join(', ')} and ${target.roles.cache.size - 11} more...`
                : roles.join(', ');
            embed.addFields({ name: `🎭 Roles [${target.roles.cache.size - 1}]`, value: roleText || 'None', inline: false });
        }

        // Permissions (if user has administrator)
        if (target.permissions.has('Administrator')) {
            embed.addFields({ name: '🔒 Key Permissions', value: '👑 Administrator', inline: true });
        } else {
            const keyPerms = [];
            if (target.permissions.has('ManageGuild')) keyPerms.push('Manage Server');
            if (target.permissions.has('ManageRoles')) keyPerms.push('Manage Roles');
            if (target.permissions.has('ManageChannels')) keyPerms.push('Manage Channels');
            if (target.permissions.has('ManageMessages')) keyPerms.push('Manage Messages');
            if (target.permissions.has('KickMembers')) keyPerms.push('Kick Members');
            if (target.permissions.has('BanMembers')) keyPerms.push('Ban Members');
            
            if (keyPerms.length > 0) {
                embed.addFields({ name: '🔒 Key Permissions', value: keyPerms.join(', '), inline: false });
            }
        }

        message.reply({ embeds: [embed] });
    },
};
