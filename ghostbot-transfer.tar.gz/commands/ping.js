// Ping command - Test bot responsiveness
const BotUtils = require('../bot');

module.exports = {
    name: 'ping',
    description: 'Check bot latency and responsiveness',
    usage: `ping`,
    execute(message, args) {
        const start = Date.now();
        
        message.reply('🏓 Pinging...').then(sentMessage => {
            const latency = Date.now() - start;
            const apiLatency = Math.round(message.client.ws.ping);
            
            const embed = BotUtils.createEmbed(
                '🏓 Pong!',
                `**Bot Latency:** ${latency}ms\n**API Latency:** ${apiLatency}ms\n**Uptime:** ${BotUtils.formatUptime(message.client.uptime)}`,
                '#00ff00'
            );
            
            sentMessage.edit({ content: '', embeds: [embed] });
        }).catch(error => {
            console.error('Error in ping command:', error);
            message.reply({ embeds: [BotUtils.createErrorEmbed('Failed to calculate ping.')] });
        });
    },
};
