// Rant command - Bot acts as a dramatic therapist responding to user rants
const { EmbedBuilder } = require('discord.js');
const BotUtils = require('../bot');
const { storage } = require('../server/storage');

module.exports = {
    name: 'rant',
    description: 'Share your rant and get a dramatic therapist response',
    usage: 'rant [your rant message]',
    async execute(message, args) {
        try {
            if (!args.length) {
                return message.reply({ 
                    embeds: [BotUtils.createErrorEmbed('Please share your rant with me.\nExample: `!rant Why do people put milk before cereal!?`')] 
                });
            }

            const rant = args.join(' ');
            
            if (rant.length > 1500) {
                return message.reply({ 
                    embeds: [BotUtils.createErrorEmbed('That\'s quite a rant! Please keep it under 1500 characters.')] 
                });
            }

            // Generate random therapist response
            const responses = [
                // Comforting responses
                {
                    type: 'comfort',
                    responses: [
                        "I hear you, and your feelings are completely valid. Let's unpack this together. *adjusts imaginary glasses*",
                        "Take a deep breath. You're in a safe space here. Tell me, how long have you been carrying this burden?",
                        "Your emotions are speaking volumes right now. It's okay to feel frustrated. *nods thoughtfully*",
                        "I can sense the passion in your words. Channel that energy into something positive, my friend.",
                        "What you're experiencing is more common than you think. You're not alone in this journey."
                    ]
                },
                // Dramatic overreactions
                {
                    type: 'dramatic',
                    responses: [
                        "OH MY GOODNESS! *dramatically faints* This is EARTH-SHATTERING! How have you survived this long?!",
                        "STOP EVERYTHING! *throws papers in the air* This is the most important issue I've heard all week!",
                        "I'm literally SHOOK! *clutches pearls* This requires immediate intervention! Call the authorities!",
                        "BREAKING NEWS: We have a CODE RED situation here! *sirens blaring* This is unprecedented!",
                        "I can't even... *paces frantically* This is bigger than all of us! We need to form a support group!"
                    ]
                },
                // Philosophical responses
                {
                    type: 'philosophical',
                    responses: [
                        "Interesting... *strokes beard* But have you considered that this rant reveals deeper truths about society?",
                        "Ah yes, this reminds me of ancient Greek philosophy. Aristotle would have had THOUGHTS about this.",
                        "Your rant has unlocked a fundamental question about human nature. Are we truly free, or slaves to our circumstances?",
                        "This is giving me major existential crisis vibes. What does it mean to truly 'rant' in this universe?",
                        "I sense this rant comes from a place of profound wisdom. You're basically a modern-day philosopher."
                    ]
                },
                // Comedic responses
                {
                    type: 'comedic',
                    responses: [
                        "Well, well, well... *taps pen* On a scale of 1 to 'screaming into the void', where are we today?",
                        "I prescribe 3 cups of tea, 2 funny cat videos, and one good nap. Take twice daily until rant subsides.",
                        "Have you tried turning your frustration off and on again? Works 60% of the time, every time.",
                        "According to my professional diagnosis... you need a hug and possibly some chocolate. *prescribes virtual hug*",
                        "I'm adding this to my case files under 'Reasons Why Humans Are Wonderfully Chaotic'. Thank you for your contribution."
                    ]
                }
            ];

            // Randomly select response type and specific response
            const responseType = responses[Math.floor(Math.random() * responses.length)];
            const specificResponse = responseType.responses[Math.floor(Math.random() * responseType.responses.length)];

            // Create response embed
            const responseEmbed = new EmbedBuilder()
                .setTitle('🛋️ Dr. Bot\'s Therapy Session')
                .addFields([
                    { name: '💭 Your Rant:', value: `"${rant}"`, inline: false },
                    { name: '🎭 Dr. Bot\'s Response:', value: specificResponse, inline: false }
                ])
                .setColor(getColorByType(responseType.type))
                .setTimestamp()
                .setFooter({ 
                    text: `Therapy Session #${Math.floor(Math.random() * 9999)} • Dr. Bot is not a licensed therapist`,
                    iconURL: message.author.displayAvatarURL()
                });

            await message.reply({ embeds: [responseEmbed] });

            // Log command
            await logCommand(message, 'rant', [responseType.type]);

        } catch (error) {
            console.error('Error in rant command:', error);
            message.reply({ 
                embeds: [BotUtils.createErrorEmbed('Dr. Bot is currently unavailable. Please try again later.')] 
            });
        }
    },
};

function getColorByType(type) {
    const colors = {
        'comfort': '#98FB98',    // Light green
        'dramatic': '#FF4500',   // Orange red
        'philosophical': '#9370DB', // Medium purple
        'comedic': '#FFD700'     // Gold
    };
    return colors[type] || '#0099ff';
}

async function logCommand(message, commandName, args) {
    try {
        let user = await storage.getUser(message.author.id);
        if (!user) {
            user = await storage.createUser({
                discordId: message.author.id,
                username: message.author.username,
                discriminator: message.author.discriminator,
                avatar: message.author.avatar
            });
        }

        let guild = await storage.getGuild(message.guild.id);
        if (!guild) {
            guild = await storage.createGuild({
                guildId: message.guild.id,
                name: message.guild.name,
                icon: message.guild.icon,
                ownerId: message.guild.ownerId,
                memberCount: message.guild.memberCount
            });
        }

        await storage.logCommand({
            userId: user.id,
            guildId: guild.id,
            commandName,
            args,
            channelId: message.channel.id,
            messageId: message.id,
            success: true
        });
    } catch (error) {
        console.error('Error logging command:', error);
    }
}