// Confess command - Send anonymous confessions to a confessions channel
const { EmbedBuilder, ChannelType } = require('discord.js');
const BotUtils = require('../bot');
const { storage } = require('../server/storage');

module.exports = {
    name: 'confess',
    description: 'Send an anonymous confession to the confessions channel',
    usage: 'confess [your confession message]',
    async execute(message, args) {
        try {
            if (!args.length) {
                return message.reply({ 
                    embeds: [BotUtils.createErrorEmbed('Please provide a confession message.\nExample: `!confess I secretly love pineapple on pizza`')] 
                });
            }

            const confession = args.join(' ');
            
            if (confession.length > 1000) {
                return message.reply({ 
                    embeds: [BotUtils.createErrorEmbed('Confession is too long! Keep it under 1000 characters.')] 
                });
            }

            // Find confessions channel (look for "confessions" in name)
            const confessionsChannel = message.guild.channels.cache.find(
                channel => channel.type === ChannelType.GuildText && 
                          channel.name.toLowerCase().includes('confess')
            );

            if (!confessionsChannel) {
                return message.reply({ 
                    embeds: [BotUtils.createErrorEmbed('No confessions channel found! Please create a channel with "confess" in the name.')] 
                });
            }

            // Create confession embed
            const confessionEmbed = new EmbedBuilder()
                .setTitle('📝 Anonymous Confession')
                .setDescription(confession)
                .setColor('#FF69B4')
                .setTimestamp()
                .setFooter({ 
                    text: 'Anonymous confession • React to show support',
                    iconURL: 'https://cdn.jsdelivr.net/gh/devicons/devicon/icons/javascript/javascript-original.svg'
                });

            // Send to confessions channel
            const sentMessage = await confessionsChannel.send({ embeds: [confessionEmbed] });
            
            // Add reaction options
            await sentMessage.react('❤️');
            await sentMessage.react('👍');
            await sentMessage.react('🤗');

            // Delete original message for anonymity
            await message.delete().catch(() => {});

            // Send confirmation to user via DM
            try {
                await message.author.send({ 
                    embeds: [BotUtils.createSuccessEmbed(`Your confession has been posted anonymously in ${confessionsChannel}!`)] 
                });
            } catch {
                // If DM fails, send temporary message that deletes after 5 seconds
                const confirmMsg = await message.channel.send({ 
                    embeds: [BotUtils.createSuccessEmbed('Confession posted! This message will delete in 5 seconds.')] 
                });
                setTimeout(() => confirmMsg.delete().catch(() => {}), 5000);
            }

            // Log command usage
            let user = await storage.getUser(message.author.id);
            if (!user) {
                user = await storage.createUser({
                    discordId: message.author.id,
                    username: message.author.username,
                    discriminator: message.author.discriminator,
                    avatar: message.author.avatar
                });
            }

            let guild = await storage.getGuild(message.guild.id);
            if (!guild) {
                guild = await storage.createGuild({
                    guildId: message.guild.id,
                    name: message.guild.name,
                    icon: message.guild.icon,
                    ownerId: message.guild.ownerId,
                    memberCount: message.guild.memberCount
                });
            }

            await storage.logCommand({
                userId: user.id,
                guildId: guild.id,
                commandName: 'confess',
                args: ['[anonymous]'], // Don't log actual confession for privacy
                channelId: message.channel.id,
                messageId: message.id,
                success: true
            });

        } catch (error) {
            console.error('Error in confess command:', error);
            message.reply({ 
                embeds: [BotUtils.createErrorEmbed('Failed to post confession. Please try again.')] 
            });
        }
    },
};