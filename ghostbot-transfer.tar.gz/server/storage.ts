const { users, guilds, guildMembers, commandLogs, moderationActions } = require("../shared/schema");
const { db } = require("./db");
const { eq, and, desc } = require("drizzle-orm");

// Storage interface for Discord bot data
export interface IStorage {
  // User operations
  getUser(discordId: string): Promise<User | undefined>;
  createUser(insertUser: InsertUser): Promise<User>;
  updateUser(discordId: string, updates: Partial<InsertUser>): Promise<User | undefined>;
  updateUserLastSeen(discordId: string): Promise<void>;
  
  // Guild operations
  getGuild(guildId: string): Promise<Guild | undefined>;
  createGuild(insertGuild: InsertGuild): Promise<Guild>;
  updateGuild(guildId: string, updates: Partial<InsertGuild>): Promise<Guild | undefined>;
  
  // Guild member operations
  getGuildMember(userId: number, guildId: number): Promise<GuildMember | undefined>;
  createGuildMember(insertMember: InsertGuildMember): Promise<GuildMember>;
  updateGuildMember(userId: number, guildId: number, updates: Partial<InsertGuildMember>): Promise<GuildMember | undefined>;
  
  // Command logging
  logCommand(commandLog: InsertCommandLog): Promise<CommandLog>;
  getCommandHistory(userId: number, guildId: number, limit?: number): Promise<CommandLog[]>;
  
  // Moderation actions
  logModerationAction(action: InsertModerationAction): Promise<ModerationAction>;
  getModerationHistory(guildId: number, limit?: number): Promise<ModerationAction[]>;
  getUserModerationHistory(userId: number, limit?: number): Promise<ModerationAction[]>;
}

export class DatabaseStorage implements IStorage {
  // User operations
  async getUser(discordId: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.discordId, discordId));
    return user || undefined;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(insertUser)
      .returning();
    return user;
  }

  async updateUser(discordId: string, updates: Partial<InsertUser>): Promise<User | undefined> {
    const [user] = await db
      .update(users)
      .set({ ...updates, updatedAt: new Date() })
      .where(eq(users.discordId, discordId))
      .returning();
    return user || undefined;
  }

  async updateUserLastSeen(discordId: string): Promise<void> {
    await db
      .update(users)
      .set({ lastSeen: new Date() })
      .where(eq(users.discordId, discordId));
  }

  // Guild operations
  async getGuild(guildId: string): Promise<Guild | undefined> {
    const [guild] = await db.select().from(guilds).where(eq(guilds.guildId, guildId));
    return guild || undefined;
  }

  async createGuild(insertGuild: InsertGuild): Promise<Guild> {
    const [guild] = await db
      .insert(guilds)
      .values(insertGuild)
      .returning();
    return guild;
  }

  async updateGuild(guildId: string, updates: Partial<InsertGuild>): Promise<Guild | undefined> {
    const [guild] = await db
      .update(guilds)
      .set({ ...updates, updatedAt: new Date() })
      .where(eq(guilds.guildId, guildId))
      .returning();
    return guild || undefined;
  }

  // Guild member operations
  async getGuildMember(userId: number, guildId: number): Promise<GuildMember | undefined> {
    const [member] = await db
      .select()
      .from(guildMembers)
      .where(and(eq(guildMembers.userId, userId), eq(guildMembers.guildId, guildId)));
    return member || undefined;
  }

  async createGuildMember(insertMember: InsertGuildMember): Promise<GuildMember> {
    const [member] = await db
      .insert(guildMembers)
      .values(insertMember)
      .returning();
    return member;
  }

  async updateGuildMember(userId: number, guildId: number, updates: Partial<InsertGuildMember>): Promise<GuildMember | undefined> {
    const [member] = await db
      .update(guildMembers)
      .set(updates)
      .where(and(eq(guildMembers.userId, userId), eq(guildMembers.guildId, guildId)))
      .returning();
    return member || undefined;
  }

  // Command logging
  async logCommand(commandLog: InsertCommandLog): Promise<CommandLog> {
    const [log] = await db
      .insert(commandLogs)
      .values(commandLog)
      .returning();
    return log;
  }

  async getCommandHistory(userId: number, guildId: number, limit: number = 50): Promise<CommandLog[]> {
    return await db
      .select()
      .from(commandLogs)
      .where(and(eq(commandLogs.userId, userId), eq(commandLogs.guildId, guildId)))
      .orderBy(desc(commandLogs.executedAt))
      .limit(limit);
  }

  // Moderation actions
  async logModerationAction(action: InsertModerationAction): Promise<ModerationAction> {
    const [moderationAction] = await db
      .insert(moderationActions)
      .values(action)
      .returning();
    return moderationAction;
  }

  async getModerationHistory(guildId: number, limit: number = 50): Promise<ModerationAction[]> {
    return await db
      .select()
      .from(moderationActions)
      .where(eq(moderationActions.guildId, guildId))
      .orderBy(desc(moderationActions.createdAt))
      .limit(limit);
  }

  async getUserModerationHistory(userId: number, limit: number = 50): Promise<ModerationAction[]> {
    return await db
      .select()
      .from(moderationActions)
      .where(eq(moderationActions.targetId, userId))
      .orderBy(desc(moderationActions.createdAt))
      .limit(limit);
  }
}

export const storage = new DatabaseStorage();