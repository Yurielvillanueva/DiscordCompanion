const { users, guilds, guildMembers, commandLogs, moderationActions } = require("../shared/schema");
const { db } = require("./db");
const { eq, and, desc } = require("drizzle-orm");

// Storage interface for Discord bot data
class DatabaseStorage {
  // User operations
  async getUser(discordId) {
    const [user] = await db.select().from(users).where(eq(users.discordId, discordId));
    return user || undefined;
  }

  async createUser(insertUser) {
    const [user] = await db
      .insert(users)
      .values(insertUser)
      .returning();
    return user;
  }

  async updateUser(discordId, updates) {
    const [user] = await db
      .update(users)
      .set({ ...updates, updatedAt: new Date() })
      .where(eq(users.discordId, discordId))
      .returning();
    return user || undefined;
  }

  async updateUserLastSeen(discordId) {
    await db
      .update(users)
      .set({ lastSeen: new Date() })
      .where(eq(users.discordId, discordId));
  }

  // Guild operations
  async getGuild(guildId) {
    const [guild] = await db.select().from(guilds).where(eq(guilds.guildId, guildId));
    return guild || undefined;
  }

  async createGuild(insertGuild) {
    const [guild] = await db
      .insert(guilds)
      .values(insertGuild)
      .returning();
    return guild;
  }

  async updateGuild(guildId, updates) {
    const [guild] = await db
      .update(guilds)
      .set({ ...updates, updatedAt: new Date() })
      .where(eq(guilds.guildId, guildId))
      .returning();
    return guild || undefined;
  }

  // Guild member operations
  async getGuildMember(userId, guildId) {
    const [member] = await db
      .select()
      .from(guildMembers)
      .where(and(eq(guildMembers.userId, userId), eq(guildMembers.guildId, guildId)));
    return member || undefined;
  }

  async createGuildMember(insertMember) {
    const [member] = await db
      .insert(guildMembers)
      .values(insertMember)
      .returning();
    return member;
  }

  async updateGuildMember(userId, guildId, updates) {
    const [member] = await db
      .update(guildMembers)
      .set(updates)
      .where(and(eq(guildMembers.userId, userId), eq(guildMembers.guildId, guildId)))
      .returning();
    return member || undefined;
  }

  // Command logging
  async logCommand(commandLog) {
    const [log] = await db
      .insert(commandLogs)
      .values(commandLog)
      .returning();
    return log;
  }

  async getCommandHistory(userId, guildId, limit = 50) {
    return await db
      .select()
      .from(commandLogs)
      .where(and(eq(commandLogs.userId, userId), eq(commandLogs.guildId, guildId)))
      .orderBy(desc(commandLogs.executedAt))
      .limit(limit);
  }

  // Moderation actions
  async logModerationAction(action) {
    const [moderationAction] = await db
      .insert(moderationActions)
      .values(action)
      .returning();
    return moderationAction;
  }

  async getModerationHistory(guildId, limit = 50) {
    return await db
      .select()
      .from(moderationActions)
      .where(eq(moderationActions.guildId, guildId))
      .orderBy(desc(moderationActions.createdAt))
      .limit(limit);
  }

  async getUserModerationHistory(userId, limit = 50) {
    return await db
      .select()
      .from(moderationActions)
      .where(eq(moderationActions.targetId, userId))
      .orderBy(desc(moderationActions.createdAt))
      .limit(limit);
  }
}

const storage = new DatabaseStorage();
module.exports = { storage };